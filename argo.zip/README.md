# AgroCulture
- AgroCulture is new way of trading Agricultural products .
- It will help farmers to commertialize their product on a online digital platform to increase the radius of their market .
- The main motto is to cut loose all the commission consumed by the third party people involved in journey of the product to the consumer.

## Technology Stack
* Frontend Development : HTML, CSS, Bootstrap3, Vanilla JS
* Server side : PHP
* Database Management : MySQL

## Traditional Way of Farming Chain
* Farmer     --> APMC (Agriculture Produce Market Committee )
* APMC       --> Wholesaler ( Securing his share 2%-10% )
* Wholesaler --> Retailer ( Securing his share roughly 10% )   
* Retailer   --> Consumer ( Securing his share roughly 10% )

## AgroCulture Way
* AgroCulture intends to establish a direct connection between Famer and the Consumer eliminating all the third party actors from the scene.
* Farmer --> AgroCulture --> Customer



